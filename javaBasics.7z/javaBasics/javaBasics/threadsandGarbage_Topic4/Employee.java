package threadsandGarbage_Topic4;

import java.util.HashSet;
import java.util.Iterator;

public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<String> set=new HashSet<String>();  
        set.add("Sneha");    
        set.add("Siri");    
        set.add("Bandhavi");   
        set.add("Ramya");  
        set.add("Deepthi");  
        Iterator<String> i=set.iterator();  
        while(i.hasNext())  
        {  
        System.out.println(i.next());  
        }  
	}
}
