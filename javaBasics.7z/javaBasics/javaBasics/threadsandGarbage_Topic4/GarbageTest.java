package threadsandGarbage_Topic4;

public class GarbageTest extends Garbage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GarbageTest t = new GarbageTest();
        t = new GarbageTest();
        t = new GarbageTest();
        System.gc();
	}
}
