package threadsandGarbage_Topic4;

public class Time {
	public static void main(String args[]) throws InterruptedException{
		
		MyThread thread = new MyThread();
		        
		        thread.start();
		        
		        try 
		        {
		            Thread.sleep(20000);
		        } 
		        catch (InterruptedException e) 
		        {
		            e.printStackTrace();
		        }
		        
		        thread.stopRunning();
		    }    

			
			}


