package threadsandGarbage_Topic4;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Telephone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 HashMap<String,Integer> map = new HashMap<String,Integer>();
	       map.put("Sneha", 739662485);
	       map.put("Sirisha",674451236);
	       map.put("Bandhavi",852485745);
	     
	       for(Map.Entry m:map.entrySet()){    
	           System.out.println(m.getKey()+" "+m.getValue());    
	          }  

	       Scanner scan = new Scanner(System.in);
	       String s = scan.next();
	       System.out.println("The Value is: " +map.get(s));
	}
}
