package threadsandGarbage_Topic4;

public class MyThread extends Thread{

private  boolean flag = true;
    
    public void stopRunning()
    {
        flag = false;
    }
    
    @Override
    public void run()
    {
        while (flag)
        {
        	System.out.println(java.time.LocalTime.now());
        	try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        
        System.out.println("Stopped Running....");
    }
}
