package threadsandGarbage_Topic4;

public class Garbage {

	public void finalize(){
		 System.out.println("object is garbage collected");
	}  
}
