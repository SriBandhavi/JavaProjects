package automobile.twoWheeler;

public class Hero extends automobile.Vehicle {
	int speed1;
	
	public String modelName() {
		// TODO Auto-generated method stub
		return "modelName";
	}

	
	public String registrationNumber() {
		// TODO Auto-generated method stub
		return "registrationNumber";
	}

	
	public String ownerName() {
		// TODO Auto-generated method stub
		return "ownerName";
	}

	
	public int speed(){
		return speed1;
	}
	public void radio() {
		System.out.println("radio method in Hero class");
	}
}
