package automobile.twoWheeler;

public class Honda extends automobile.Vehicle  {
	int Hondaspeed;
	int cdPlayervar;

	@Override
	public String modelName() {
		System.out.println("honda modelName");
		return "honda modelName";
	}

	@Override
	public String registrationNumber() {
		System.out.println("honda reg no");
		return "honda reg no";
	}

	@Override
	public String ownerName() {
		System.out.println("honda ownerName");
		return "honda ownerName";
	}

	public int speed(){
		System.out.println("Hondaspeed");
		return Hondaspeed;
	}
	public int cdplayer()  {
		System.out.println("cdPlayervar");
		return cdPlayervar;
		
	}
	public static void main(String[] args){
		Honda honda=new Honda();
		honda.ownerName();
		honda.registrationNumber();
		honda.speed();
		honda.cdplayer();
		honda.modelName();
	}
}
