package automobile;

public abstract class Vehicle {
	public abstract String modelName();
	public abstract String registrationNumber();
	public abstract String ownerName();


}
