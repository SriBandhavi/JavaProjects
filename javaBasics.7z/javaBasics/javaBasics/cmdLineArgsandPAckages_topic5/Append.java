package threadsandGarbage_Topic4;

import java.util.Scanner;

public class Append {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan= new Scanner(System.in);
		String s1 = scan.next();
		String s2 = scan.next();
		System.out.println(s1+" Technologies "+s2);
	}
}
