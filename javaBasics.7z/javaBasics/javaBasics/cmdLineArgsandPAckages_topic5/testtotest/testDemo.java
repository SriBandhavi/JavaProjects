package testtotest;
import test.*;

public class testDemo {

	public static void main(String[] args) {
		Foundation test=new Foundation();
		//System.out.println("Private variable:  "+test.Var1);
		//System.out.println("Default variable"+test.Var2);
		//System.out.println("protected variable"+test.Var3);
		System.out.println("private variable"+test.Var4);
		

	}

}
