//Write a program to find greatest number in an array
package javaBasicsTopic1;

import java.util.Scanner;

public class GreatestNumInArray {

	public static void main(String[] args) {
		int num;
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter number of elements in the array:");
		num = scanner.nextInt();
		int numArray[] = new int[num];
		System.out.println("Enter elements of array:");
		int max = numArray[0];
		for (int i = 0; i < num; i++) {
			numArray[i] = scanner.nextInt();

			if (numArray[i] > max)
				max = numArray[i];
		}
		System.out.println("Maximum value:" + max);
	}

}
