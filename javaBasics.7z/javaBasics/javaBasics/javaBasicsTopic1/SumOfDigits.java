/*5.Write a program that will accept a 4 digit number(assume that the user enters only 4 digit nos.)
and print the sum of all the 4 digits. For ex : If the number passed is 3629, the program should
print �The sum of all the digits entered is 20�
*/

package javaBasicsTopic1;

import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter 4 digits number: ");
		int number = input.nextInt();
		int sum=0;
		if(number>=1000 & number<10000){
			
			while (number != 0) 
	        { 
	            sum = sum +number % 10; 
	            number = number/10; 
	        } 
			System.out.println("The sum of all the digits entered is: "+sum);
			
		}
		else
			System.out.println("Enter 4 digit numbers Only");
		

	}

}
