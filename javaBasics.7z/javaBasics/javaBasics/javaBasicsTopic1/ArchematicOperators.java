
/*2.Write a Java program to print the result of the following operations. Declare variables and
initialize them with given values
a. -5 + 8 * 6
b. (55+9) % 9
c. 20 + -3*5 / 8
d. 5 + 15 / 3 * 2 - 8 % 3*/

package javaBasicsTopic1;

public class ArchematicOperators {

	public static void main(String[] args) {
		int a=5;
		int b=8;
		int c=6;
		int d=20;
		int e=55;
		int f=9;
		int g=3;
		int h=15;
		int z=2;
		
		System.out.println("-5 + 8 * 6 ="+"  " +(-a+b*c));
		System.out.println("(55+9) % 9 = " +" "+(e+f)%f);
		System.out.println("20 + -3*5 / 8 = " +" "+(d+-g*a/b));
		System.out.println("5 + 15 / 3 * 2 - 8 % 3* = " +" "+(a+h/g*z-b%g));

	}

}
