package objOrientedTopic2;

import java.util.Scanner;

public class Magazine extends Book1{

	
		// TODO Auto-generated method stub

		static String type;

		public Magazine(int isbn, String title, double price, String type) {
			super(isbn, title, price);
			this.type = type;
		}



		public static void main(String[] args) {
			// TODO Auto-generated method stub

			Scanner scan = new Scanner(System.in);
			Magazine m = new Magazine(scan.nextInt(),scan.next(),scan.nextDouble(),scan.next());
			
			System.out.println("Isbn:"+isbn+"\ntitle:"+title+"\nprice:"+price+"\ntype:"+type);

	}

}
