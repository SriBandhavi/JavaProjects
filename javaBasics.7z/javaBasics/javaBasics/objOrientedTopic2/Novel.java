package objOrientedTopic2;

import java.util.Scanner;

public class Novel extends Book1 {

	static String author;

	public Novel(int isbn, String title, double price, String author) {
		super(isbn, title, price);
		this.author = author;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		Novel n = new Novel(scan.nextInt(),scan.next(),scan.nextDouble(),scan.next());
		
		System.out.println("Isbn:"+isbn+"\ntitle:"+title+"\nprice:"+price+"\nauthor:"+author);
}
}
