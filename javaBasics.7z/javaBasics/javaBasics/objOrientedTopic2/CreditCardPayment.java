package objOrientedTopic2;

import java.util.Date;

public class CreditCardPayment extends Payment {

	String name;
	String expiryDate;
	int creditCardNmbr;
	
	
	
	public CreditCardPayment(String name, String expiryDate, int creditCardNmbr) {
		super();
		this.name = name;
		this.expiryDate = expiryDate;
		this.creditCardNmbr = creditCardNmbr;
	}
	public void  paymentDetails(){
		System.out.println("card details:");
		System.out.println("name on card:"+name);
		System.out.println("Expiry Date:"+expiryDate);
		System.out.println("card number:"+creditCardNmbr);
		
		} 
	public static void main(String args[]){
		CashPayment cashpayment1=new CashPayment();
		CashPayment cashpayment2=new CashPayment();
		CreditCardPayment ccpayment1=new CreditCardPayment("Sri","12/12/2019",123456789);
		CreditCardPayment ccpayment2=new CreditCardPayment("Sneha","11/12/2019",123456781);
		cashpayment1.paymentDetails();
		cashpayment2.paymentDetails();
		ccpayment1.paymentDetails();
		ccpayment2.paymentDetails();
		
	}
}
