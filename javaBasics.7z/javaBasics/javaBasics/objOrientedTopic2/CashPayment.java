package objOrientedTopic2;

public class CashPayment extends Payment {
	
	CashPayment(){
		System.out.println("Constructor is invoked");
		}
	
	public void  paymentDetails(){
		System.out.println("The amount of the payment is done in cash");
		} 

}
