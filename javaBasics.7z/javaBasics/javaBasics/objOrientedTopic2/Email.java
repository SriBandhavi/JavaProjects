package objOrientedTopic2;

public class Email extends Document {
	
	String sender;
	String recipient;
	String title;
	
	
	

	public Email(String text2, String sender, String recipient, String title) {
		super(text2);
		this.sender = sender;
		this.recipient = recipient;
		this.title = title;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}


@Override
	public String toString() {
		return "Email sender=" + sender + ",\n recipient=" + recipient + ",\n title=" + title ;
	}

public static void main(String[] args) {
	
	Email e=new Email("about java","Sri","Bandhavi","Spring boot");
	System.out.println(e.toString()+ "\nEmail body: "+e.getText());
	
		

	}

}
