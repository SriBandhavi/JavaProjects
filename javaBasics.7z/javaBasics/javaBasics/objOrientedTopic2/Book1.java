package objOrientedTopic2;

public class Book1 {

	static int isbn;
	static String title;
	static double price;
	Book1(int isbn, String title, double price) {
		this.isbn = isbn;
		this.title = title;
		this.price = price;
}
}