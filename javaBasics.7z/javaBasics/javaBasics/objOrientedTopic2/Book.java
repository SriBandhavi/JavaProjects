/*
 * Write a program to create a class Book with the following
- attributes: -isbn, title, author, price
 - methods :
 i. Initialize the data members through parameterized constructor
 ii. displaydeta ils() to display the details of the book
 iii. discountedprice() : pass the discount percent, calculate the discount on price and find
the amount to be paid after discount
 - task :
 Create an object book, initialize the book and display the details along with the discounted
price
 */
package objOrientedTopic2;

public class Book {
	int isbn;
	float price;
	String title,author;
	public Book(int isbn, float price, String title, String author) {
		super();
		this.isbn = isbn;
		this.price = price;
		this.title = title;
		this.author = author;
	}
	public void displayDetails(){
		System.out.println("book details: " +"\n isbn number :" +this.isbn + "\nPrice:  " + this.price
				+ "\n Title: " + this.title+ "\n Author:  " + this.author);
	}
	
	public void discountedprice(float percentage){
		
		price=price*(percentage/100);
		System.out.println(price);
		System.out.println(percentage);
		System.out.println("Discounted Price of the book  after a discounf of "+percentage+"% is: "+price) ;
		
	}
	public static void main(String args[]){
		Book book=new Book(1012,2500,"JavaBaics","James Gosling");
		book.displayDetails();
		book.discountedprice(70);		
	}
		
	}
	
	


