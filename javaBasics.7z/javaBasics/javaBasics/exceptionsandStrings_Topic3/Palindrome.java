package exceptionsandStrings_Topic3;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan= new Scanner(System.in);
		String s1 = scan.next();
		StringBuffer b= new StringBuffer(s1);
		String s2 = b.reverse().toString();
		if(s1.equalsIgnoreCase(s2)){
			System.out.println("String is the Palindrome");
		}
		else{
			System.out.println("String is not the Palindrome");
		}
	}
}
