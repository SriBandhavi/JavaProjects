package exceptionsandStrings_Topic3;

import java.util.Scanner;

public class NumberFormat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan= new Scanner(System.in);
		
		try {
			
			String s1 = scan.next();
			System.out.println("Entered Student1 Name: "+s1);
			String s2 = scan.next();
			System.out.println("Entered Student2 Name "+s2);
			System.out.println("Enter marks: ");
			int n1 = Integer.parseInt(scan.next());
			int n2 = Integer.parseInt(scan.next());
			int n3 = Integer.parseInt(scan.next());
			int n4 = Integer.parseInt(scan.next());
			int n5 = Integer.parseInt(scan.next());
			int n6 = Integer.parseInt(scan.next());
			int avg1 = (n1+n2+n3)/3;
			int avg2 = (n4+n5+n6)/3;
			System.out.println("The Student "+s1+" got average of "+avg1);
			System.out.println("The Student "+s2+" got average of "+avg2);
	    } catch (NumberFormatException e) {
	    	System.out.println("Number Format Exception");
	    }
	}
}
