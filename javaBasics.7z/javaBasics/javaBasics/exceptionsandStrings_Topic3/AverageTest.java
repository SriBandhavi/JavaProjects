/*
 * Write a program to accept 5 integers passed as arguments while executing the class. Find the
average of these 5 nos. Use ArrayIndexOutofBounds exception to handle situation where the
user might have entered less than 5 integers.
 */
package exceptionsandStrings_Topic3;

import java.util.Scanner;

public class AverageTest {
	public static void main(String[] args) {
		int ass[] = new int[5];
		int len = ass.length;
		int sum = 0;
		try {

			Scanner sc = new Scanner(System.in);
			System.out.println("enter 5 digits:");

			for (int i = 0; i < len; i++) {
				ass[i] = sc.nextInt();
				sum = sum + ass[i];
			}
			if (len == 5) {

				System.out.println("Average= " + (sum / 5));
			}

			else if (len < 5)
				throw new ArrayIndexOutOfBoundsException("Out of Bounds Exc. Size is 4 or more");
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}

	}
}
