/*
 Write a program to accept name and age of a person from the command prompt(passed as
arguments when you execute the class) and ensure that the age entered is >=18 and < 60. Display
proper error messages. The program must exit gracefully after displaying the error message in
case the arguments passed are not proper. (Hint : Create a user defined exception class for
handling errors.)
 */
package exceptionsandStrings_Topic3;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Person {

	public static void main(String[] args) {

		
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter name: ");
			String name = scanner.next();
			System.out.println("Enter age: ");
			int age = scanner.nextInt();
			if (age >= 18 && age < 60)
				System.out.println("entered age is" + age);
			else
				System.out.println("age entered should between >=18 and < 60" );
				
		}
			catch (InputMismatchException e1) {
				System.out.println("age entered should between >=18 and < 60" + e1);
		}catch(Exception e) {
			System.out.println(" Exception :age entered should between >=18 and < 60" + e);
		}
			
		}

	}


